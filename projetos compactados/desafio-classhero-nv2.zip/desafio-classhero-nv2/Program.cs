﻿class Program {
    static void Main()
    {
        string nome = "João";  // Alterei de aspas simples para aspas duplas
        double valorProduto = 29.99; // Alterei o tipo de int para double e a virgula para um ponto
        char resposta = 'S'; // Alterei de aspas duplas para aspas simples e de ponto para ponto e virgula

        Console.WriteLine("nome: " + nome);
        Console.WriteLine("valor do produto: " + valorProduto);
        Console.WriteLine("resposta: " + resposta);
    }
}
