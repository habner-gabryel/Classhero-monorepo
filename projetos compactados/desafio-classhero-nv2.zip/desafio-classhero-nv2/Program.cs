﻿class Program {
    static void Main()
    {
        double notaProva = 8.5;
        int quantAlunos = 40;
        string nomeCurso = "Ciência da Computação";
        char statusPagamento = 'P';

        Console.WriteLine("Nota da Prova: " + notaProva);
        Console.WriteLine("Quantidade de Alunos: " + quantAlunos);
        Console.WriteLine("Nome do Curso: " + nomeCurso);
        Console.WriteLine("Status de Pagamento: " + statusPagamento);
    }
}
