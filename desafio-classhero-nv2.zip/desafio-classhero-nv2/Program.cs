﻿class Program {
    static void Main()
    {
        double resultado = 0.1 + 0.2 + 0.3;
        Console.WriteLine("Resultado da soma 0.1 + 0.2 + 0.3 = " + resultado);
    }
}
